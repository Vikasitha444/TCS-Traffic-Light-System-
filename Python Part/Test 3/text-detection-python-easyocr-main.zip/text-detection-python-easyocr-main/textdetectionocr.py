import cv2
import easyocr
import matplotlib.pyplot as plt
import numpy as np



#read image 

image_path = "stop2.jpeg"

img = cv2.imread(image_path)

# instanace text detector

reader = easyocr.Reader(["en"],gpu=False)

#detect text on image

text_ = reader.readtext(img)

threshold = 0.25

# draw bbox and text

for t_,t in enumerate(text_):

    print(t_)
    bbox , text, score = t
    if score > threshold:
    	cv2.rectangle(img,bbox[0], bbox[2],(0,255,0),5)
    	cv2.putText(img,text,bbox[0],cv2.FONT_HERSHEY_COMPLEX,2,(255,0,0),2)


plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))

plt.show()